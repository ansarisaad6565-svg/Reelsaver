package com.reeldl.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class LoginActivity : Activity() {
    private fun loggedIn() =
        CookieManager.getInstance().getCookie("https://www.instagram.com")
            ?.contains("sessionid") == true

    private fun finishIfLoggedIn() {
        if (loggedIn()) {
            CookieManager.getInstance().flush()
            Toast.makeText(this, "Login save ho gaya. Ab reel share karo!", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    finishIfLoggedIn()
                }
            }
            loadUrl("https://www.instagram.com/accounts/login/")
        }
        val btn = Button(this).apply {
            text = "Login ho gaya - Save karo"
            setOnClickListener {
                if (loggedIn()) finishIfLoggedIn()
                else Toast.makeText(this@LoginActivity, "Pehle Instagram me login karo", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(btn)
        root.addView(web, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
