package com.reeldl.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class Palette(
    val name: String,
    val bg: Int,
    val card: Int,
    val text: Int,
    val sub: Int,
    val accent: Int,
    val onAccent: Int,
    val light: Boolean
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("reelsaver", Context.MODE_PRIVATE)
    fun theme(c: Context): Int = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, i: Int) { sp(c).edit().putInt("theme", i).apply() }
    fun maxQuality(c: Context): Boolean = sp(c).getBoolean("maxq", true)
    fun setMaxQuality(c: Context, v: Boolean) { sp(c).edit().putBoolean("maxq", v).apply() }
}

object Themes {
    private fun c(s: String) = Color.parseColor(s)
    val all: List<Palette> = listOf(
        Palette("Dark", c("#0F1115"), c("#1B1F27"), c("#FFFFFF"), c("#9AA4B2"), c("#7C3AED"), c("#FFFFFF"), false),
        Palette("Light", c("#F4F5F7"), c("#FFFFFF"), c("#111827"), c("#6B7280"), c("#7C3AED"), c("#FFFFFF"), true),
        Palette("Amoled Black", c("#000000"), c("#121212"), c("#FFFFFF"), c("#9CA3AF"), c("#22C55E"), c("#000000"), false),
        Palette("Ocean", c("#0B1B2B"), c("#12304A"), c("#FFFFFF"), c("#8FB3D1"), c("#06B6D4"), c("#00131A"), false),
        Palette("Sunset", c("#1F0F14"), c("#3A1822"), c("#FFFFFF"), c("#D1A3AE"), c("#F97316"), c("#1A0A00"), false)
    )

    fun current(ctx: Context): Palette = all[Prefs.theme(ctx).coerceIn(0, all.size - 1)]
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun roundBg(color: Int, radius: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    return g
}

@Suppress("DEPRECATION")
fun Activity.styleWindow(p: Palette) {
    window.statusBarColor = p.bg
    window.navigationBarColor = p.bg
    var flags = 0
    if (p.light) {
        flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
    window.decorView.systemUiVisibility = flags
}

fun Context.pill(text: String, p: Palette, filled: Boolean): Button {
    val b = Button(this)
    b.text = text
    b.isAllCaps = false
    b.textSize = 15f
    b.stateListAnimator = null
    b.setTextColor(if (filled) p.onAccent else p.text)
    b.background = roundBg(if (filled) p.accent else p.card, dp(14).toFloat())
    b.setPadding(dp(16), dp(14), dp(16), dp(14))
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(10)
    b.layoutParams = lp
    return b
}

fun Context.label(text: String, p: Palette, size: Float, color: Int, bold: Boolean, center: Boolean): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
    if (center) t.gravity = Gravity.CENTER
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(6)
    t.layoutParams = lp
    return t
}

fun Context.card(p: Palette): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.background = roundBg(p.card, dp(18).toFloat())
    l.setPadding(dp(18), dp(16), dp(18), dp(16))
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(14)
    l.layoutParams = lp
    return l
}

fun Context.logoView(): ImageView {
    val iv = ImageView(this)
    iv.setImageResource(R.drawable.ic_launcher_foreground)
    val bg = GradientDrawable()
    bg.shape = GradientDrawable.OVAL
    bg.setColor(Color.parseColor("#7C3AED"))
    iv.background = bg
    val lp = LinearLayout.LayoutParams(dp(96), dp(96))
    lp.gravity = Gravity.CENTER_HORIZONTAL
    lp.topMargin = dp(8)
    iv.layoutParams = lp
    return iv
}
