package com.reeldl.app

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch

class SettingsActivity : Activity() {

    override fun onResume() {
        super.onResume()
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val pal = Themes.current(this)
        styleWindow(pal)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(pal.bg)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(24))
        scroll.addView(col, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(label("Settings", pal, 26f, pal.text, true, false))

        // Themes
        val themeCard = card(pal)
        themeCard.addView(label("Theme", pal, 16f, pal.text, true, false))
        val cur = Prefs.theme(this).coerceIn(0, Themes.all.size - 1)
        Themes.all.forEachIndexed { i, t ->
            val b = pill(if (i == cur) t.name + "  ✓" else t.name, pal, i == cur)
            b.setOnClickListener {
                Prefs.setTheme(this, i)
                setContentView(buildUi())
            }
            themeCard.addView(b)
        }
        col.addView(themeCard)

        // Quality
        val qCard = card(pal)
        qCard.addView(label("Quality", pal, 16f, pal.text, true, false))
        val sw = Switch(this)
        sw.text = "Instagram: Max quality (HD merge)"
        sw.setTextColor(pal.text)
        sw.isChecked = Prefs.maxQuality(this)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setMaxQuality(this, v) }
        qCard.addView(sw)
        qCard.addView(label(
            "ON: Instagram ki sabse high quality (video+audio merge hoke). " +
                "Download thoda der se hoga. Agar merge fail ho to normal quality save hoti hai.",
            pal, 13f, pal.sub, false, false))
        col.addView(qCard)

        // Account
        val aCard = card(pal)
        val loggedIn = Downloader.cookies().contains("sessionid")
        aCard.addView(label("Instagram account", pal, 16f, pal.text, true, false))
        aCard.addView(label(
            if (loggedIn) "Login hai ✅" else "Login nahi hai ❌", pal, 14f, pal.sub, false, false))
        if (loggedIn) {
            val lo = pill("Logout", pal, false)
            lo.setOnClickListener {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                setContentView(buildUi())
            }
            aCard.addView(lo)
        } else {
            val li = pill("Login", pal, true)
            li.setOnClickListener {
                startActivity(android.content.Intent(this, LoginActivity::class.java))
            }
            aCard.addView(li)
        }
        col.addView(aCard)

        // About
        val about = card(pal)
        about.addView(label("About", pal, 16f, pal.text, true, false))
        about.addView(label("Developer: Saad", pal, 15f, pal.text, false, false))
        about.addView(label("Reel Saver v1.2 (Instagram + YouTube)", pal, 13f, pal.sub, false, false))
        about.addView(label(
            "Sirf apne personal use ke liye. Dusron ka content bina permission repost mat karo.",
            pal, 12f, pal.sub, false, false))
        col.addView(about)

        val back = pill("Back", pal, false)
        back.setOnClickListener { finish() }
        col.addView(back)

        return scroll
    }
}
