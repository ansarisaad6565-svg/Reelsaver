package com.reeldl.app

import org.schabi.newpipe.extractor.downloader.Downloader as NpDownloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.net.HttpURLConnection
import java.net.URL

class YtHttp : NpDownloader() {

    private val ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

    override fun execute(request: Request): Response {
        val c = URL(request.url()).openConnection() as HttpURLConnection
        c.requestMethod = request.httpMethod()
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", ua)
        for ((k, vs) in request.headers()) {
            if (k.equals("Accept-Encoding", true)) continue
            vs.forEachIndexed { i, v ->
                if (i == 0) c.setRequestProperty(k, v) else c.addRequestProperty(k, v)
            }
        }
        val data = request.dataToSend()
        if (data != null) {
            c.doOutput = true
            c.outputStream.use { it.write(data) }
        }
        val code = c.responseCode
        if (code == 429) {
            c.disconnect()
            throw ReCaptchaException("reCaptcha Challenge requested", request.url())
        }
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        val headers = HashMap<String, List<String>>()
        for ((k, v) in c.headerFields) {
            if (k != null) headers[k] = v
        }
        return Response(code, c.responseMessage ?: "", headers, body, c.url.toString())
    }
}
