package com.reeldl.app

import android.content.Context
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

object Yt {
    private var inited = false

    /** kind: 0 = audio only, 1 = ready video (video+audio), 2 = merge MP4, 3 = merge WEBM */
    class Option(
        val label: String,
        val audioOnly: Boolean,
        val kind: Int,
        val video: VideoStream?,
        val audio: AudioStream?
    )

    class Info(val title: String, val options: List<Option>)

    fun isYouTube(text: String): Boolean =
        Regex("(youtube\\.com|youtu\\.be)", RegexOption.IGNORE_CASE).containsMatchIn(text)

    private fun extractUrl(text: String): String? =
        Regex("https?://[^\\s]+").findAll(text).map { it.value }
            .firstOrNull { it.contains("youtu", true) }

    private fun init() {
        if (!inited) {
            NewPipe.init(YtHttp(), Localization("en", "US"))
            inited = true
        }
    }

    private fun mimeOf(url: String): String {
        val m = Regex("[?&]mime=([^&]+)").find(url)?.groupValues?.get(1) ?: return ""
        return try { URLDecoder.decode(m, "UTF-8") } catch (_: Exception) { m }
    }

    fun load(text: String): Info {
        init()
        val url = extractUrl(text) ?: throw RuntimeException("YouTube link nahi mila")
        val info = StreamInfo.getInfo(url)

        val audios = info.audioStreams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val orig = audios.filter { it.audioTrackType == null || it.audioTrackType.toString() == "ORIGINAL" }
        val pool = if (orig.isNotEmpty()) orig else audios
        val m4a = pool.filter { mimeOf(it.content).contains("mp4") }.maxByOrNull { it.averageBitrate }
        val webmA = pool.filter { mimeOf(it.content).contains("webm") }.maxByOrNull { it.averageBitrate }

        val vOnly = info.videoOnlyStreams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val muxed = info.videoStreams.filter {
            it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && !it.isVideoOnly()
        }
        val heights = (vOnly.map { it.height } + muxed.map { it.height })
            .filter { it > 0 }.distinct().sortedDescending()

        val opts = mutableListOf<Option>()
        for (h in heights) {
            val mp4 = vOnly.filter {
                it.height == h && (it.codec ?: "").startsWith("avc1") && mimeOf(it.content).contains("mp4")
            }.maxByOrNull { it.bitrate }
            val web = vOnly.filter {
                it.height == h && mimeOf(it.content).contains("webm")
            }.maxByOrNull { it.bitrate }
            val mx = muxed.firstOrNull { it.height == h }
            val hd = if (h >= 720) " HD" else ""
            if (mp4 != null && m4a != null) {
                opts.add(Option("🎬 ${h}p$hd  •  MP4", false, 2, mp4, m4a))
            } else if (web != null && webmA != null) {
                opts.add(Option("🎬 ${h}p$hd  •  WEBM", false, 3, web, webmA))
            } else if (mx != null) {
                opts.add(Option("🎬 ${h}p  •  MP4 (ready)", false, 1, mx, null))
            }
        }
        if (m4a != null) {
            opts.add(Option("🎵 Audio M4A  •  ${m4a.averageBitrate} kbps", true, 0, null, m4a))
        }
        if (webmA != null) {
            opts.add(Option("🎵 Audio Opus  •  ${webmA.averageBitrate} kbps (best)", true, 0, null, webmA))
        }
        if (opts.isEmpty()) throw RuntimeException("Koi stream nahi mila")
        return Info(info.name ?: "YouTube", opts)
    }

    /** Chunked download (YouTube throttles long single requests). */
    private fun fetchYt(url: String, dest: File, onPct: (Int) -> Unit) {
        val clen = Regex("[?&]clen=(\\d+)").find(url)?.groupValues?.get(1)?.toLongOrNull() ?: -1L
        if (clen <= 0) {
            Downloader.fetch(url, dest, onPct)
            return
        }
        dest.outputStream().use { out ->
            var start = 0L
            val chunk = 9L * 1024 * 1024
            val buf = ByteArray(128 * 1024)
            var last = -1
            while (start < clen) {
                val end = minOf(start + chunk, clen) - 1
                val c = URL("$url&range=$start-$end").openConnection() as HttpURLConnection
                c.setRequestProperty("User-Agent", Extractor.UA)
                c.connectTimeout = 15000
                c.readTimeout = 30000
                if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}")
                var got = 0L
                c.inputStream.use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        start += n
                        val p = (start * 100 / clen).toInt()
                        if (p != last) { last = p; onPct(p) }
                    }
                }
                if (got == 0L) throw RuntimeException("server ne data nahi diya")
            }
        }
    }

    fun download(ctx: Context, o: Option, title: String, progress: (String) -> Unit): Outcome {
        val safe = title.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim().take(80)
            .ifEmpty { "youtube" }
        val cache = ctx.cacheDir
        val tag = System.currentTimeMillis()
        return try {
            when (o.kind) {
                0 -> {
                    val a = o.audio!!
                    val webm = mimeOf(a.content).contains("webm")
                    val ext = if (webm) "webm" else "m4a"
                    val f = File(cache, "yt_$tag.$ext")
                    try {
                        fetchYt(a.content, f) { progress("Audio download... $it%") }
                        val ok = Downloader.saveMedia(ctx, f, "$safe.$ext",
                            if (webm) "audio/webm" else "audio/mp4", 2)
                        if (ok) Outcome(true, "Audio save ho gaya ✅\nMusic > ReelSaver folder")
                        else Outcome(false, "Save fail ho gaya")
                    } finally { f.delete() }
                }
                1 -> {
                    val vs = o.video!!
                    val f = File(cache, "yt_$tag.mp4")
                    try {
                        fetchYt(vs.content, f) { progress("Video ${vs.height}p download... $it%") }
                        val ok = Downloader.saveMedia(ctx, f, "$safe.mp4", "video/mp4", 1)
                        if (ok) Outcome(true, "Video save ho gaya ✅\nGallery > ReelSaver folder")
                        else Outcome(false, "Save fail ho gaya")
                    } finally { f.delete() }
                }
                else -> {
                    val vs = o.video!!
                    val au = o.audio!!
                    val webm = o.kind == 3
                    val ext = if (webm) "webm" else "mp4"
                    val v = File(cache, "yt_$tag.v")
                    val a = File(cache, "yt_$tag.a")
                    val out = File(cache, "yt_$tag.$ext")
                    try {
                        fetchYt(vs.content, v) { progress("Video ${vs.height}p download... $it%") }
                        fetchYt(au.content, a) { progress("Audio download... $it%") }
                        progress("HD merge ho raha hai...")
                        Downloader.mux(v, a, out, webm)
                        val ok = Downloader.saveMedia(ctx, out, "$safe.$ext",
                            if (webm) "video/webm" else "video/mp4", 1)
                        if (ok) Outcome(true, "Video ${vs.height}p save ho gaya ✅\nGallery > ReelSaver folder")
                        else Outcome(false, "Save fail ho gaya")
                    } finally { v.delete(); a.delete(); out.delete() }
                }
            }
        } catch (e: Exception) {
            Outcome(false, "Error: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
