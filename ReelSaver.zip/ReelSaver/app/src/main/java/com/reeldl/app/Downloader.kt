package com.reeldl.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

class Outcome(val ok: Boolean, val msg: String, val needLogin: Boolean = false)

object Downloader {

    fun cookies(): String =
        CookieManager.getInstance().getCookie("https://www.instagram.com") ?: ""

    fun run(ctx: Context, text: String, progress: (String) -> Unit): Outcome {
        val code = Extractor.shortcode(text)
            ?: return Outcome(false, "Valid Instagram link nahi mila")
        val ck = cookies()
        val session = ck.contains("sessionid")
        progress("Link check ho raha hai...")

        var list: List<Media>? = null
        if (session) list = Extractor.findMedia(code, ck)
        if (list.isNullOrEmpty()) {
            val u = Extractor.findVideoUrl(code)
            if (u != null) list = listOf(Media(true, u, 0, null, null, 0))
        }
        val items = list
        if (items.isNullOrEmpty()) {
            return if (!session) Outcome(false, "Pehle Instagram login karo", true)
            else Outcome(false, "Error: ${Extractor.lastError}")
        }

        val maxq = Prefs.maxQuality(ctx)
        var saved = 0
        items.forEachIndexed { i, m ->
            val label = if (items.size > 1) " (${i + 1}/${items.size})" else ""
            try {
                if (saveOne(ctx, code, i + 1, m, maxq, label, progress)) saved++
            } catch (e: Exception) {
                Extractor.lastError = e.message ?: "unknown"
            }
        }
        return if (saved > 0)
            Outcome(true, "$saved file save ho gayi ✅\nGallery > ReelSaver folder")
        else Outcome(false, "Download fail: ${Extractor.lastError}")
    }

    private fun saveOne(
        ctx: Context, code: String, idx: Int, m: Media, maxq: Boolean,
        label: String, progress: (String) -> Unit
    ): Boolean {
        val cache = ctx.cacheDir
        val base = "ReelSaver_${code}_$idx"

        if (!m.isVideo) {
            val f = File(cache, "$base.jpg")
            fetch(m.url, f) { progress("Photo$label download... $it%") }
            val ok = saveToGallery(ctx, f, "$base.jpg", "image/jpeg", false)
            f.delete()
            return ok
        }

        val out = File(cache, "$base.mp4")
        var done = false
        val dv = m.dashVideo
        val da = m.dashAudio
        if (maxq && dv != null && da != null && m.dashHeight > m.height) {
            val v = File(cache, "$base.v.mp4")
            val a = File(cache, "$base.a.mp4")
            try {
                fetch(dv, v) { progress("HD video$label download... $it%") }
                progress("Audio$label download...")
                fetch(da, a) { }
                progress("HD merge ho raha hai...")
                mux(v, a, out)
                done = out.length() > 0
            } catch (e: Exception) {
                Extractor.lastError = "HD: " + (e.message ?: "unknown")
                done = false
            } finally {
                v.delete(); a.delete()
            }
            if (!done) out.delete()
        }
        if (!done) {
            fetch(m.url, out) { progress("Video$label download... $it%") }
        }
        val ok = saveToGallery(ctx, out, "$base.mp4", "video/mp4", true)
        out.delete()
        return ok
    }

    private fun fetch(url: String, dest: File, onPct: (Int) -> Unit) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", Extractor.UA)
        c.connectTimeout = 15000
        c.readTimeout = 30000
        if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}")
        val total = c.contentLengthLong
        c.inputStream.use { ins ->
            dest.outputStream().use { outs ->
                val buf = ByteArray(128 * 1024)
                var read = 0L
                var last = -1
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    outs.write(buf, 0, n)
                    read += n
                    if (total > 0) {
                        val p = (read * 100 / total).toInt()
                        if (p != last) { last = p; onPct(p) }
                    }
                }
            }
        }
    }

    private fun pickTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith(prefix)) return i
        }
        throw RuntimeException("track nahi mila: $prefix")
    }

    private fun copyTrack(ex: MediaExtractor, muxer: MediaMuxer, dst: Int) {
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            buf.clear()
            val n = ex.readSampleData(buf, 0)
            if (n < 0) break
            val flags =
                if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                    MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            info.set(0, n, ex.sampleTime, flags)
            muxer.writeSampleData(dst, buf, info)
            ex.advance()
        }
    }

    private fun mux(video: File, audio: File, out: File) {
        val ve = MediaExtractor()
        val ae = MediaExtractor()
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            ve.setDataSource(video.path)
            ae.setDataSource(audio.path)
            val vt = pickTrack(ve, "video/")
            val at = pickTrack(ae, "audio/")
            ve.selectTrack(vt)
            ae.selectTrack(at)
            val vd = muxer.addTrack(ve.getTrackFormat(vt))
            val ad = muxer.addTrack(ae.getTrackFormat(at))
            muxer.start()
            copyTrack(ve, muxer, vd)
            copyTrack(ae, muxer, ad)
            muxer.stop()
        } finally {
            try { muxer.release() } catch (_: Exception) { }
            ve.release()
            ae.release()
        }
    }

    private fun saveToGallery(ctx: Context, src: File, name: String, mime: String, isVideo: Boolean): Boolean {
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        val dir = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/ReelSaver")
        val col = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val uri = ctx.contentResolver.insert(col, values) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { o ->
            src.inputStream().use { it.copyTo(o) }
        } ?: return false
        return true
    }
}
