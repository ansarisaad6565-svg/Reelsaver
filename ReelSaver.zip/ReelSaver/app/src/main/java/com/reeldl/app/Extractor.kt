package com.reeldl.app

import java.net.HttpURLConnection
import java.net.URL

object Extractor {
    const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    fun shortcode(text: String): String? =
        Regex("instagram\\.com/(?:[^/\\s]+/)?(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)")
            .find(text)?.groupValues?.get(1)

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun normalize(s: String) = s
        .replace("\\\"", "\"")
        .replace("\\/", "/")
        .replace("\\u0026", "&")
        .replace("&amp;", "&")

    /** Returns the best (highest quality) direct video URL Instagram exposes. */
    fun findVideoUrl(code: String): String? {
        val pages = listOf(
            "https://www.instagram.com/reel/$code/embed/captioned/",
            "https://www.instagram.com/p/$code/embed/captioned/",
            "https://www.instagram.com/reel/$code/"
        )
        for (p in pages) {
            try {
                val html = normalize(get(p))
                Regex("\"video_url\":\"(https[^\"]+)\"").find(html)
                    ?.let { return it.groupValues[1] }
                Regex("property=\"og:video(?::secure_url)?\" content=\"(https[^\"]+)\"")
                    .find(html)?.let { return it.groupValues[1] }
            } catch (_: Exception) { }
        }
        return null
    }
}
