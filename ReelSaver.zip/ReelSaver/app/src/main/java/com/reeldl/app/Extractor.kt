package com.reeldl.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Extractor {
    const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    private const val IG_UA =
        "Instagram 275.0.0.27.98 Android (33/13; 420dpi; 1080x2400; Google; Pixel 7; panther; panther; en_US; 458229237)"

    @Volatile var lastError: String = ""

    fun shortcode(text: String): String? =
        Regex("instagram\\.com/(?:[^/\\s]+/)?(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)")
            .find(text)?.groupValues?.get(1)

    private fun mediaId(code: String): Long {
        val alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        var id = 0L
        for (ch in code.take(11)) id = id * 64 + alpha.indexOf(ch)
        return id
    }

    private fun get(url: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        val code = c.responseCode
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Best video URL from an Instagram media item JSON (highest resolution). */
    private fun bestVideo(item: JSONObject): String? {
        val vv = item.optJSONArray("video_versions")
        if (vv != null && vv.length() > 0) {
            var best: String? = null
            var area = -1L
            for (i in 0 until vv.length()) {
                val v = vv.getJSONObject(i)
                val a = v.optLong("width") * v.optLong("height")
                if (a > area) { area = a; best = v.optString("url") }
            }
            if (!best.isNullOrEmpty()) return best
        }
        val car = item.optJSONArray("carousel_media")
        if (car != null) {
            for (i in 0 until car.length()) {
                bestVideo(car.getJSONObject(i))?.let { return it }
            }
        }
        return null
    }

    /** Logged-in method (uses the user's own Instagram session). Works for private accounts the user follows. */
    fun findWithSession(code: String, cookies: String): String? {
        return try {
            val h = mutableMapOf(
                "User-Agent" to IG_UA,
                "X-IG-App-ID" to "936619743392459",
                "Cookie" to cookies,
                "Accept-Language" to "en-US"
            )
            Regex("csrftoken=([^;]+)").find(cookies)?.let { h["X-CSRFToken"] = it.groupValues[1] }
            val text = get("https://i.instagram.com/api/v1/media/${mediaId(code)}/info/", h)
            val items = JSONObject(text).getJSONArray("items")
            bestVideo(items.getJSONObject(0)).also {
                if (it == null) lastError = "is post me video nahi mila"
            }
        } catch (e: Exception) {
            lastError = e.message ?: "unknown"
            null
        }
    }

    private fun normalize(s: String) = s
        .replace("\\\"", "\"")
        .replace("\\/", "/")
        .replace("\\u0026", "&")
        .replace("&amp;", "&")

    /** Anonymous fallback (public reels only). */
    fun findVideoUrl(code: String): String? {
        val pages = listOf(
            "https://www.instagram.com/reel/$code/embed/captioned/",
            "https://www.instagram.com/p/$code/embed/captioned/",
            "https://www.instagram.com/reel/$code/"
        )
        for (p in pages) {
            try {
                val html = normalize(get(p, mapOf("User-Agent" to UA)))
                Regex("\"video_url\":\"(https[^\"]+)\"").find(html)
                    ?.let { return it.groupValues[1] }
                Regex("property=\"og:video(?::secure_url)?\" content=\"(https[^\"]+)\"")
                    .find(html)?.let { return it.groupValues[1] }
            } catch (_: Exception) { }
        }
        return null
    }
}
