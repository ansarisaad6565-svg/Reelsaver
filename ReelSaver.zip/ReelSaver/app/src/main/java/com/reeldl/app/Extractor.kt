package com.reeldl.app

import org.json.JSONObject
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.xml.parsers.DocumentBuilderFactory

data class Media(
    val isVideo: Boolean,
    val url: String,
    val height: Int,
    val dashVideo: String?,
    val dashAudio: String?,
    val dashHeight: Int
)

object Extractor {
    const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    private const val IG_UA =
        "Instagram 275.0.0.27.98 Android (33/13; 420dpi; 1080x2400; Google; Pixel 7; panther; panther; en_US; 458229237)"

    @Volatile var lastError: String = ""

    fun shortcode(text: String): String? =
        Regex("instagram\\.com/(?:[^/\\s]+/)?(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)")
            .find(text)?.groupValues?.get(1)

    private fun mediaId(code: String): Long {
        val alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        var id = 0L
        for (ch in code.take(11)) id = id * 64 + alpha.indexOf(ch)
        return id
    }

    private fun get(url: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        val code = c.responseCode
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Parse DASH manifest: best H.264 video + best AAC audio. Returns (videoUrl, audioUrl, height). */
    private fun parseDash(xml: String): Triple<String?, String?, Int> {
        var bestV: String? = null
        var bestH = 0
        var bestVBw = 0
        var bestA: String? = null
        var bestABw = 0
        try {
            val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(InputSource(StringReader(xml)))
            val reps = doc.getElementsByTagName("Representation")
            for (i in 0 until reps.length) {
                val el = reps.item(i) as Element
                val parent = el.parentNode as? Element
                val codecs = el.getAttribute("codecs")
                val kind = (el.getAttribute("mimeType") + " " +
                    (parent?.getAttribute("mimeType") ?: "") + " " +
                    (parent?.getAttribute("contentType") ?: ""))
                val base = el.getElementsByTagName("BaseURL").item(0)?.textContent?.trim()
                    ?: continue
                val bw = el.getAttribute("bandwidth").toIntOrNull() ?: 0
                val h = el.getAttribute("height").toIntOrNull() ?: 0
                if (codecs.startsWith("avc1")) {
                    if (h > bestH || (h == bestH && bw > bestVBw)) {
                        bestH = h; bestVBw = bw; bestV = base
                    }
                } else if (codecs.startsWith("mp4a") || kind.contains("audio")) {
                    if (bw > bestABw) { bestABw = bw; bestA = base }
                }
            }
        } catch (_: Exception) { }
        return Triple(bestV, bestA, bestH)
    }

    private fun parseItem(item: JSONObject, out: MutableList<Media>) {
        val car = item.optJSONArray("carousel_media")
        if (car != null && car.length() > 0) {
            for (i in 0 until car.length()) parseItem(car.getJSONObject(i), out)
            return
        }
        val vv = item.optJSONArray("video_versions")
        if (vv != null && vv.length() > 0) {
            var bestUrl = ""
            var bestH = 0
            var area = -1L
            for (i in 0 until vv.length()) {
                val v = vv.getJSONObject(i)
                val a = v.optLong("width") * v.optLong("height")
                if (a > area) { area = a; bestUrl = v.optString("url"); bestH = v.optInt("height") }
            }
            var dv: String? = null
            var da: String? = null
            var dh = 0
            val dash = item.optString("video_dash_manifest", "")
            if (dash.isNotEmpty()) {
                val t = parseDash(dash)
                dv = t.first; da = t.second; dh = t.third
            }
            if (bestUrl.isNotEmpty()) out.add(Media(true, bestUrl, bestH, dv, da, dh))
            return
        }
        val cands = item.optJSONObject("image_versions2")?.optJSONArray("candidates")
        if (cands != null && cands.length() > 0) {
            var bestUrl = ""
            var area = -1L
            var bestH = 0
            for (i in 0 until cands.length()) {
                val c = cands.getJSONObject(i)
                val a = c.optLong("width") * c.optLong("height")
                if (a > area) { area = a; bestUrl = c.optString("url"); bestH = c.optInt("height") }
            }
            if (bestUrl.isNotEmpty()) out.add(Media(false, bestUrl, bestH, null, null, 0))
        }
    }

    /** Logged-in method: reels, videos, photos and carousels. */
    fun findMedia(code: String, cookies: String): List<Media>? {
        return try {
            val h = mutableMapOf(
                "User-Agent" to IG_UA,
                "X-IG-App-ID" to "936619743392459",
                "Cookie" to cookies,
                "Accept-Language" to "en-US"
            )
            Regex("csrftoken=([^;]+)").find(cookies)?.let { h["X-CSRFToken"] = it.groupValues[1] }
            val text = get("https://i.instagram.com/api/v1/media/${mediaId(code)}/info/", h)
            val items = JSONObject(text).getJSONArray("items")
            val out = mutableListOf<Media>()
            parseItem(items.getJSONObject(0), out)
            if (out.isEmpty()) lastError = "is post me media nahi mila"
            out
        } catch (e: Exception) {
            lastError = e.message ?: "unknown"
            null
        }
    }


    private fun post(url: String, body: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun nodeToMedia(n: JSONObject, out: MutableList<Media>) {
        val video = n.optString("video_url", "")
        if (n.optBoolean("is_video") && video.isNotEmpty()) {
            val h = n.optJSONObject("dimensions")?.optInt("height") ?: 0
            out.add(Media(true, video, h, null, null, 0))
        } else {
            val img = n.optString("display_url", "")
            if (img.isNotEmpty()) out.add(Media(false, img, 0, null, null, 0))
        }
    }

    /** No-login methods (public posts/reels only). Best effort, Instagram may block. */
    fun findAnonymous(code: String): List<Media>? {
        val out = mutableListOf<Media>()
        try {
            val vars = """{"shortcode":"$code","fetch_tagged_user_count":null,"hoisted_comment_id":null,"hoisted_reply_id":null}"""
            val body = "variables=" + URLEncoder.encode(vars, "UTF-8") + "&doc_id=8845758582119845"
            val text = post(
                "https://www.instagram.com/graphql/query", body,
                mapOf(
                    "User-Agent" to UA,
                    "X-IG-App-ID" to "936619743392459",
                    "X-CSRFToken" to "x",
                    "Cookie" to "csrftoken=x",
                    "Referer" to "https://www.instagram.com/"
                )
            )
            val media = JSONObject(text).getJSONObject("data").optJSONObject("xdt_shortcode_media")
            if (media != null) {
                val kids = media.optJSONObject("edge_sidecar_to_children")?.optJSONArray("edges")
                if (kids != null && kids.length() > 0) {
                    for (i in 0 until kids.length()) {
                        nodeToMedia(kids.getJSONObject(i).getJSONObject("node"), out)
                    }
                } else {
                    nodeToMedia(media, out)
                }
            }
        } catch (e: Exception) {
            lastError = e.message ?: "unknown"
        }
        if (out.isNotEmpty()) return out
        val u = findVideoUrl(code)
        if (u != null) return listOf(Media(true, u, 0, null, null, 0))
        return null
    }

    private fun normalize(s: String) = s
        .replace("\\\"", "\"")
        .replace("\\/", "/")
        .replace("\\u0026", "&")
        .replace("&amp;", "&")

    /** Anonymous fallback (public reels only). */
    fun findVideoUrl(code: String): String? {
        val pages = listOf(
            "https://www.instagram.com/reel/$code/embed/captioned/",
            "https://www.instagram.com/p/$code/embed/captioned/",
            "https://www.instagram.com/reel/$code/"
        )
        for (p in pages) {
            try {
                val html = normalize(get(p, mapOf("User-Agent" to UA)))
                Regex("\"video_url\":\"(https[^\"]+)\"").find(html)
                    ?.let { return it.groupValues[1] }
                Regex("property=\"og:video(?::secure_url)?\" content=\"(https[^\"]+)\"")
                    .find(html)?.let { return it.groupValues[1] }
            } catch (_: Exception) { }
        }
        return null
    }
}
