package com.reeldl.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout

class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pal = Themes.current(this)
        val text = if (intent?.action == Intent.ACTION_SEND)
            intent.getStringExtra(Intent.EXTRA_TEXT) else null
        if (text == null) { finish(); return }

        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.parseColor("#99000000"))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.background = roundBg(pal.card, dp(22).toFloat())
        card.setPadding(dp(24), dp(24), dp(24), dp(24))
        card.addView(logoView())
        val status = label("Shuru ho raha hai...", pal, 16f, pal.text, false, true)
        card.addView(status)

        val lp = FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.CENTER
        frame.addView(card, lp)
        setContentView(frame)

        val appCtx = applicationContext
        Thread {
            val r = Downloader.run(appCtx, text) { msg ->
                runOnUiThread { status.text = msg }
            }
            runOnUiThread {
                status.text = r.msg
                Handler(Looper.getMainLooper()).postDelayed({
                    if (r.needLogin) {
                        startActivity(Intent(this@ShareActivity, LoginActivity::class.java))
                    }
                    finish()
                }, if (r.ok) 1500L else 2500L)
            }
        }.start()
    }
}
