package com.reeldl.app

import android.app.Activity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object YtUi {
    fun showOptions(
        act: Activity, pal: Palette, title: String, options: List<Yt.Option>,
        box: LinearLayout, status: TextView, afterDone: (Outcome) -> Unit
    ) {
        box.removeAllViews()
        box.addView(act.label(title, pal, 15f, pal.text, true, false))
        val buttons = mutableListOf<Button>()

        fun add(o: Yt.Option) {
            val b = act.pill(o.label, pal, true)
            buttons.add(b)
            b.setOnClickListener {
                buttons.forEach { it.isEnabled = false }
                val appCtx = act.applicationContext
                Thread {
                    val r = Yt.download(appCtx, o, title) { msg ->
                        act.runOnUiThread { status.text = msg }
                    }
                    act.runOnUiThread {
                        status.text = r.msg
                        buttons.forEach { it.isEnabled = true }
                        afterDone(r)
                    }
                }.start()
            }
            box.addView(b)
        }

        val videos = options.filter { !it.audioOnly }
        val audios = options.filter { it.audioOnly }
        if (videos.isNotEmpty()) {
            box.addView(act.label("🎬 Video (HD quality)", pal, 14f, pal.sub, true, false))
            videos.forEach { add(it) }
        }
        if (audios.isNotEmpty()) {
            box.addView(act.label("🎵 Sirf Audio", pal, 14f, pal.sub, true, false))
            audios.forEach { add(it) }
        }
    }
}
