package com.reeldl.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private var typed = ""

    override fun onResume() {
        super.onResume()
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val pal = Themes.current(this)
        styleWindow(pal)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(pal.bg)
        scroll.isFillViewport = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(24))
        scroll.addView(col, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(logoView())
        col.addView(label("Reel Saver", pal, 26f, pal.text, true, true))
        col.addView(label("by Saad", pal, 14f, pal.sub, false, true))

        val loggedIn = Downloader.cookies().contains("sessionid")
        val c1 = card(pal)
        c1.addView(label(
            if (loggedIn) "Instagram: login hai ✅" else "Instagram: login nahi hai ❌",
            pal, 16f, pal.text, true, false))
        c1.addView(label(
            "Reel ya post me Share > Reel Saver dabao, ya neeche link paste karo.",
            pal, 13f, pal.sub, false, false))
        if (!loggedIn) {
            val b = pill("Instagram Login (ek baar)", pal, true)
            b.setOnClickListener { startActivity(Intent(this, LoginActivity::class.java)) }
            c1.addView(b)
        }
        col.addView(c1)

        val c2 = card(pal)
        val input = EditText(this)
        input.hint = "https://www.instagram.com/reel/..."
        input.setText(typed)
        input.setTextColor(pal.text)
        input.setHintTextColor(pal.sub)
        input.inputType = InputType.TYPE_TEXT_VARIATION_URI
        c2.addView(input)
        val status = label("", pal, 14f, pal.sub, false, true)
        val dl = pill("Download", pal, true)
        dl.setOnClickListener {
            typed = input.text.toString()
            dl.isEnabled = false
            val appCtx = applicationContext
            val link = typed
            Thread {
                val r = Downloader.run(appCtx, link) { msg ->
                    runOnUiThread { status.text = msg }
                }
                runOnUiThread {
                    status.text = r.msg
                    dl.isEnabled = true
                    if (r.needLogin) {
                        startActivity(Intent(this@MainActivity, LoginActivity::class.java))
                    }
                }
            }.start()
        }
        c2.addView(dl)
        c2.addView(status)
        col.addView(c2)

        val st = pill("⚙  Settings", pal, false)
        st.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        col.addView(st)

        return scroll
    }
}
