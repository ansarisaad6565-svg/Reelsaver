package com.reeldl.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.ViewGroup
import android.webkit.CookieManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var status: TextView? = null

    private fun cookies(): String =
        CookieManager.getInstance().getCookie("https://www.instagram.com") ?: ""

    private fun hasSession() = cookies().contains("sessionid")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = if (intent?.action == Intent.ACTION_SEND)
            intent.getStringExtra(Intent.EXTRA_TEXT) else null

        if (shared != null) {
            startDownload(shared, closeWhenDone = true)
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(48, 120, 48, 48)
        }
        status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.BLACK)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Instagram Login (ek baar)"
            setOnClickListener { startActivity(Intent(this@MainActivity, LoginActivity::class.java)) }
        })
        val input = EditText(this).apply { hint = "Reel link yahan paste karo" }
        root.addView(input, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "Download"
            setOnClickListener { startDownload(input.text.toString(), false) }
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        status?.text = "Reel Saver\n\n" +
            (if (hasSession()) "Login: HAAN ✅" else "Login: NAHI ❌ (pehle login karo)") +
            "\n\nInstagram me Reel > Share > Reel Saver select karo, ya link paste karo."
    }

    private fun startDownload(text: String, closeWhenDone: Boolean) {
        val ctx = applicationContext
        val code = Extractor.shortcode(text)
        if (code == null) {
            Toast.makeText(ctx, "Valid Instagram link nahi mila", Toast.LENGTH_LONG).show()
            if (closeWhenDone) finish()
            return
        }
        Toast.makeText(ctx, "Download ki taiyari...", Toast.LENGTH_SHORT).show()
        val cookieStr = cookies()
        val session = cookieStr.contains("sessionid")

        Thread {
            var url: String? = null
            if (session) url = Extractor.findWithSession(code, cookieStr)
            if (url == null) url = Extractor.findVideoUrl(code)
            runOnUiThread {
                if (url == null) {
                    if (!session) {
                        Toast.makeText(ctx, "Pehle Instagram login karo", Toast.LENGTH_LONG).show()
                        startActivity(Intent(this, LoginActivity::class.java))
                    } else {
                        Toast.makeText(ctx, "Error: ${Extractor.lastError}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val req = DownloadManager.Request(Uri.parse(url))
                        .setTitle("Reel $code")
                        .addRequestHeader("User-Agent", Extractor.UA)
                        .setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS, "ReelSaver/reel_$code.mp4")
                    (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager)
                        .enqueue(req)
                    Toast.makeText(ctx, "Download shuru! Downloads/ReelSaver me milega",
                        Toast.LENGTH_LONG).show()
                }
                if (closeWhenDone) finish()
            }
        }.start()
    }
}
