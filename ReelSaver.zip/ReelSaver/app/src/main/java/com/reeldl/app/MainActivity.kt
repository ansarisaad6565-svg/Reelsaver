package com.reeldl.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = if (intent?.action == Intent.ACTION_SEND)
            intent.getStringExtra(Intent.EXTRA_TEXT) else null

        if (shared != null) {
            startDownload(shared, closeWhenDone = true)
            return
        }

        // Normal launch: simple paste-and-download screen
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(48, 120, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Reel Saver\n\nInstagram me Reel > Share > Reel Saver select karo.\nYa link yahan paste karo:"
            textSize = 16f
            setTextColor(Color.BLACK)
        })
        val input = EditText(this).apply { hint = "https://www.instagram.com/reel/..." }
        root.addView(input, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "Download"
            setOnClickListener { startDownload(input.text.toString(), false) }
        })
        setContentView(root)
    }

    private fun startDownload(text: String, closeWhenDone: Boolean) {
        val ctx = applicationContext
        val code = Extractor.shortcode(text)
        if (code == null) {
            Toast.makeText(ctx, "Valid Instagram link nahi mila", Toast.LENGTH_LONG).show()
            if (closeWhenDone) finish()
            return
        }
        Toast.makeText(ctx, "Download ki taiyari...", Toast.LENGTH_SHORT).show()

        Thread {
            val url = Extractor.findVideoUrl(code)
            runOnUiThread {
                if (url == null) {
                    Toast.makeText(ctx,
                        "Video link nahi mila (private reel ya Instagram ne block kiya)",
                        Toast.LENGTH_LONG).show()
                } else {
                    val req = DownloadManager.Request(Uri.parse(url))
                        .setTitle("Reel $code")
                        .addRequestHeader("User-Agent", Extractor.UA)
                        .setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS, "ReelSaver/reel_$code.mp4")
                    (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager)
                        .enqueue(req)
                    Toast.makeText(ctx, "Download shuru! Downloads/ReelSaver me milega",
                        Toast.LENGTH_LONG).show()
                }
                if (closeWhenDone) finish()
            }
        }.start()
    }
}
